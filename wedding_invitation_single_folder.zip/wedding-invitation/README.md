# Wedding Invitation Builder

## Cài đặt
- `npm install`
- `npm run dev`

## Deploy trên Vercel
1. Tạo tài khoản tại https://vercel.com
2. Kết nối GitHub
3. Deploy repo này
